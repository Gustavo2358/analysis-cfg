window.SYMBOL_TABLE_DATA={
"meta":{"source":"literal.cbl","scopes":5,"symbols":1,"dataSymbols":0,"procedureSymbols":0,"fileSymbols":0,"diagnostics":0},
"sourceLines":["IDENTIFICATION DIVISION.","PROGRAM-ID. CALLER.","PROCEDURE DIVISION.","    CALL 'PROGA'.","    GOBACK.",""],
"scopes":[{"id":0,"p":-1,"k":"ROOT","n":"<root>","o":-1,"a":-1},{"id":1,"p":0,"k":"PROGRAM","n":"CALLER","o":0,"a":0},{"id":2,"p":1,"k":"DIVISION","n":"IDENTIFICATION","o":-1,"a":1},{"id":3,"p":1,"k":"DIVISION","n":"PROCEDURE","o":-1,"a":2},{"id":4,"p":3,"k":"PARAGRAPH","n":"<entry>","o":-1,"a":3}],
"symbols":[{"id":0,"k":"PROGRAM","ns":"PROGRAM","n":"CALLER","c":"CALLER","s":0,"a":0,"l":1,"e":5,"x":{"common":"false","initial":"false","recursive":"false","library":"false","definition":"false"}}],
"kindCounts":{"PROGRAM":1},
"diagnostics":[]};
