window.SYMBOL_TABLE_DATA={
"meta":{"source":"dynamic-no-move.cbl","scopes":8,"symbols":2,"dataSymbols":1,"procedureSymbols":0,"fileSymbols":0,"diagnostics":0},
"sourceLines":["IDENTIFICATION DIVISION.","PROGRAM-ID. CALLER.","DATA DIVISION.","WORKING-STORAGE SECTION.","01 WS-PGM PIC X(8).","PROCEDURE DIVISION.","    CALL WS-PGM.","    GOBACK.",""],
"scopes":[{"id":0,"p":-1,"k":"ROOT","n":"<root>","o":-1,"a":-1},{"id":1,"p":0,"k":"PROGRAM","n":"CALLER","o":0,"a":0},{"id":2,"p":1,"k":"DIVISION","n":"IDENTIFICATION","o":-1,"a":1},{"id":3,"p":1,"k":"DIVISION","n":"DATA","o":-1,"a":2},{"id":4,"p":3,"k":"SECTION","n":"Working Storage Section","o":-1,"a":3},{"id":5,"p":4,"k":"DATA_ITEM","n":"WS-PGM","o":1,"a":4},{"id":6,"p":1,"k":"DIVISION","n":"PROCEDURE","o":-1,"a":6},{"id":7,"p":6,"k":"PARAGRAPH","n":"<entry>","o":-1,"a":7}],
"symbols":[{"id":0,"k":"PROGRAM","ns":"PROGRAM","n":"CALLER","c":"CALLER","s":0,"a":0,"l":1,"e":8,"x":{"common":"false","initial":"false","recursive":"false","library":"false","definition":"false"}},{"id":1,"k":"DATA_ITEM","ns":"DATA","n":"WS-PGM","c":"WS-PGM","s":4,"a":4,"l":5,"e":5,"x":{"level":"01","levelKind":"GROUP_OR_ELEMENTARY","visibility":"LOCAL","declaration":"01 WS-PGM PIC X(8)."}}],
"kindCounts":{"DATA_ITEM":1,"PROGRAM":1},
"diagnostics":[]};
