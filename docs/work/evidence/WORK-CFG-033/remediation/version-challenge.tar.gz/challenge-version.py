import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/home/gustavo/workspace/teste-e2e/analysis-cfg')
work=root.parent/'.cp6-w1d-remediation/development/version-challenge';work.mkdir()
path=root/'cfg-adapters/src/main/java/io/github/gustavo2358/analysis/cfg/adapters/CfgJsonWriter.java';original=path.read_bytes()
command=['mvn','-B','-ntp','-pl','cfg-adapters','-am','test','-Dtest=BuildCfgContractTest,W1dInvokeWireTest']
def sha(data):return hashlib.sha256(data).hexdigest()
def run(name):
 p=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log=work/(name+'.log');log.write_bytes(p.stdout)
 report=root/'cfg-adapters/target/surefire-reports/TEST-io.github.gustavo2358.analysis.cfg.adapters.W1dInvokeWireTest.xml'
 (work/(name+'.xml')).write_bytes(report.read_bytes());suite=ET.parse(report).getroot()
 return dict(command=command,exitCode=p.returncode,log=log.name,logSha256=sha(p.stdout),tests=int(suite.attrib['tests']),failures=int(suite.attrib['failures']),errors=int(suite.attrib['errors']),skipped=int(suite.attrib['skipped']),compileError=b'COMPILATION ERROR' in p.stdout)
receipt=dict(originalSha256=sha(original),mutants=[])
try:
 receipt['firstGreen']=run('first-green');assert receipt['firstGreen']['exitCode']==0
 for name,old,new in [('force-v1','out.string(requiresV2 ? "2.0.0" : "1.0.0");','out.string("1.0.0");'),('force-v2','out.string(requiresV2 ? "2.0.0" : "1.0.0");','out.string("2.0.0");'),('invoke-as-jump','INVOKE_NORMAL("INVOKE_NORMAL", true)','INVOKE_NORMAL("JUMP", true)')]:
  assert original.decode().count(old)==1
  changed=original.decode().replace(old,new).encode();path.write_bytes(changed)
  result=run(name);result.update(name=name,mutatedSha256=sha(changed));receipt['mutants'].append(result)
  path.write_bytes(original);result['byteExactRestore']=path.read_bytes()==original
  assert result['exitCode']!=0 and result['failures']>0 and not result['errors'] and not result['skipped'] and not result['compileError']
  print(name,result['failures'],'semantic failures; restored',flush=True)
 receipt['secondGreen']=run('second-green');assert receipt['secondGreen']['exitCode']==0
 receipt['result']='PASS'
finally:
 path.write_bytes(original);receipt['restoredSha256']=sha(path.read_bytes());(work/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
