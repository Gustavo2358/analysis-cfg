window.SEMANTIC_COVERAGE_DATA={
"meta":{"source":"semantic-product-entry-goback.cbl","complete":true,"unresolvedCopies":0,"lexerErrors":0,"parserErrors":0},
"constructionCounts":{"INPUT_MISSING":0,"MODELED":1,"PRESERVED_UNINTERPRETED":0,"UNSUPPORTED":0},
"dependencyCounts":{"DEPENDENCY_UNKNOWN":0,"NOT_DEPENDENCY_BEARING":1,"REFERENCE_READY":0},
"metrics":{"dataReferences":0,"qualifiedDataReferences":0,"subscriptedDataReferences":0,"modifiedDataReferences":0,"preservedDataReferences":0,"procedureReferences":0,"fileReferences":0,"programReferences":0,"modeledStatements":0,"preservedStatements":0,"typedDataClauses":0,"preservedDataClauses":0,"opaqueExpressions":0,"embeddedLanguages":0},
"findings":[{"id":0,"ast":5,"parse":22,"line":4,"sourceLine":4,"rule":"gobackStatement","coverage":"MODELED","dependency":"NOT_DEPENDENCY_BEARING","sourceFile":"semantic-product-entry-goback.cbl","text":"GOBACK","reason":"Flow statement is structurally modeled and does not itself name a dependency."}],
"blockingReasons":[]};
