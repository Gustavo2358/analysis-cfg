window.RESOLUTION_DATA={
"meta":{"source":"semantic-product-entry-goback.cbl","compilationUnitId":"SEMANTIC-PRODUCT-ENTRY-GOBACK.CBL","policyId":"cobol-explorer/explicit-options","policyVersion":"3.0.0","qualifyMode":"UNSPECIFIED","pgmnameMode":"UNSPECIFIED","dynamMode":"UNSPECIFIED","dllMode":"UNSPECIFIED","claim":"COMPLETE","copyInputCompleteness":"COMPLETE","referenceBindingComplete":true,"dependencyAnalysisReady":true,"programUnits":1,"references":0,"externalClassifications":0,"unresolvedCopies":0,"gaps":0},
"completeness":{"blockingReasons":[]},
"counts":{"status":{"RESOLVED":0,"EXTERNAL_OBSERVED":0,"AMBIGUOUS":0,"UNRESOLVED":0,"UNSUPPORTED":0},"reason":{"UNIQUE_VISIBLE_DECLARATION":0,"QUALIFIED_HIERARCHY_MATCH":0,"LITERAL_EXTERNAL_PROGRAM":0,"MULTIPLE_VALID_CANDIDATES":0,"DECLARATION_NOT_FOUND":0,"INPUT_INCOMPLETE":0,"UNSUPPORTED_GRAMMAR_FORM":0,"UNSUPPORTED_DIALECT_OPTION":0,"INVALID_NAMESPACE_FOR_CONTEXT":0},"syntacticKind":{"DATA":0,"CONDITION":0,"INDEX":0,"PROCEDURE":0,"FILE":0,"PROGRAM":0,"PRESERVED_NAMED":0},"resolvedSemanticKind":{"DATA":0,"CONDITION":0,"INDEX":0,"PROCEDURE":0,"FILE":0,"PROGRAM":0,"PRESERVED_NAMED":0},"role":{"VALUE_READ":0,"VALUE_WRITE":0,"CALL_TARGET":0,"CALL_ARGUMENT":0,"CALL_RETURNING":0,"QUALIFIER_COMPONENT":0,"SUBSCRIPT":0,"REFERENCE_MODIFICATION_OFFSET":0,"REFERENCE_MODIFICATION_LENGTH":0,"GO_TO_TARGET":0,"GO_TO_SELECTOR":0,"PERFORM_FROM":0,"PERFORM_THROUGH":0,"REDEFINES_TARGET":0,"RENAMES_FROM":0,"RENAMES_THROUGH":0,"OCCURS_DEPENDING_ON":0,"OCCURS_KEY":0,"OCCURS_INDEX":0,"PROCEDURE_PARAMETER":0,"PROCEDURE_RETURNING":0,"FILE_OPERATION":0,"DECLARATION_RELATION":0,"CONTEXT_DEPENDENT":0}},
"metrics":{"indexedDeclarations":2,"nominalLookups":0,"candidateInspections":0,"maximumCandidates":0,"collectedReferences":0},
"sourceLines":["IDENTIFICATION DIVISION.","PROGRAM-ID. AIR-FIRST.","PROCEDURE DIVISION.","    GOBACK.","END PROGRAM AIR-FIRST.",""],
"units":[{"id":"SEMANTIC-PRODUCT-ENTRY-GOBACK.CBL::0::AIR-FIRST","path":"0","name":"AIR-FIRST","canonicalName":"AIR-FIRST","parentId":null,"references":0,"resolved":0,"externalObserved":0,"ambiguous":0,"unresolved":0,"unsupported":0,"gaps":0,"complete":true}],
"entries":[],
"classifications":[],
"gaps":[],
"diagnostics":[],
"relations":[]};
